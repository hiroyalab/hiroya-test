# Pyarmor 8.5.2 (trial), 000000, 2024-05-21T11:01:00.287425
from .pyarmor_runtime import __pyarmor__
