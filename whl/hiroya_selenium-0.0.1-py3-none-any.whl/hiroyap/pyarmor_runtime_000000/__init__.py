# Pyarmor 8.5.2 (trial), 000000, 2024-04-16T13:55:52.279715
from .pyarmor_runtime import __pyarmor__
